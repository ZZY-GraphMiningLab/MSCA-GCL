import torch
z1=torch.randn(2708,6)
z2=torch.randn(2708,6)
mean = 0
std_dev = 0.1  # 标准差可以根据你的需求调整

# 计算向量长度的一半
n = z1.shape[1] // 2

# 生成高斯噪声
noise = torch.randn_like(z1) * std_dev


z1_first_half = z1[:, :n]
z1_second_half = z1[:, n:]
z2_first_half = z2[:, :n]
z2_second_half = z2[:, n:]
noise_first_half = noise[:, :n]
noise_second_half = noise[:, n:]
# 构建 z1，前一半保持不变，后一半添加了噪声
z1_addnoise = torch.cat([z1_first_half, noise_second_half], dim=1)

# 构建 z2，前一半添加了噪声，后一半保持不变
z2_addnoise = torch.cat([noise_first_half, z2_second_half], dim=1)