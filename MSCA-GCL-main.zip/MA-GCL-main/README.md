## MSCA-GCL

For example, to run MSCA-GCL under Cora, execute:

    python main.py --device cuda:0 --dataset Cora
    
