from typing import Optional

import torch
from torch import nn
import torch.nn.functional as F
import random
import numpy as np
from torch_geometric.nn import GCNConv, GATConv
import faiss
from utils import repeat_1d_tensor
from torch.nn import Sequential, Linear, ReLU
from torch_geometric.nn import MessagePassing
from torch_geometric.utils import add_self_loops, degree
from torch_geometric.datasets import TUDataset

import torch
from torch.nn import Parameter
from torch_scatter import scatter_add
from torch_geometric.nn.conv import MessagePassing
from torch_geometric.utils import add_remaining_self_loops
import math
from typing import Optional
from typing import Optional, Tuple, Union

import torch
import torch.nn.functional as F
from torch import Tensor
from torch.nn import Parameter
from torch_sparse import SparseTensor, set_diag

from torch_geometric.nn.dense.linear import Linear
from torch_geometric.typing import (
    Adj,
    NoneType,
    OptPairTensor,
    OptTensor,
    Size,
)
from torch_geometric.utils import add_self_loops, remove_self_loops, softmax

#from ..inits import glorot, zeros
import torch
from torch import nn
import torch.nn.functional as F
from utils import create_adjacency_matrix
from torch_geometric.nn import GCNConv


class Encoder(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, activation, base_model=GCNConv, k: int = 2, skip=False):
        super(Encoder, self).__init__()
        self.base_model = base_model

        assert k >= 2
        self.k = k
        self.skip = skip
        if not self.skip:
            self.conv = [base_model(in_channels, 2 * out_channels).jittable()]
            for _ in range(1, k - 1):
                self.conv.append(base_model(2 * out_channels, 2 * out_channels))
            self.conv.append(base_model(2 * out_channels, out_channels))
            self.conv = nn.ModuleList(self.conv)

            self.activation = activation
        else:
            self.fc_skip = nn.Linear(in_channels, out_channels)
            self.conv = [base_model(in_channels, out_channels)]
            for _ in range(1, k):
                self.conv.append(base_model(out_channels, out_channels))
            self.conv = nn.ModuleList(self.conv)

            self.activation = activation

    def forward(self, x: torch.Tensor, edge_index: torch.Tensor):
        if not self.skip:
            for i in range(self.k):
                x = self.activation(self.conv[i](x, edge_index))
            return x
        else:
            h = self.activation(self.conv[0](x, edge_index))
            hs = [self.fc_skip(x), h]
            for i in range(1, self.k):
                u = sum(hs)
                hs.append(self.activation(self.conv[i](u, edge_index)))
            return hs[-1]


class GRACE(torch.nn.Module):
    def __init__(self, encoder: Encoder, num_hidden: int, num_proj_hidden: int, tau: float = 0.5):
        super(GRACE, self).__init__()
        self.encoder: Encoder = encoder
        self.tau: float = tau

        self.fc1 = torch.nn.Linear(num_hidden, num_proj_hidden)
        self.fc2 = torch.nn.Linear(num_proj_hidden, num_hidden)

        self.num_hidden = num_hidden

        # self.fc = torch.nn.Linear(in_ft, out_ft, bias=False)
        self.act = torch.nn.PReLU()
        self.to_q = torch.nn.Linear(num_hidden, num_hidden, bias=False)
        self.to_k = torch.nn.Linear(num_hidden, num_hidden, bias=False)
        self.to_v = torch.nn.Sequential(nn.Linear(num_hidden, num_hidden, bias=False),
                                  nn.PReLU(),
                                  nn.Linear(num_hidden, num_hidden, bias=False)
                                  )


    def forward(self, x: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        return self.encoder(x, edge_index)

    def projection(self, z: torch.Tensor) -> torch.Tensor:
        z = F.elu(self.fc1(z))
        return self.fc2(z)

    def sim(self, z1: torch.Tensor, z2: torch.Tensor):
        z1 = F.normalize(z1)
        z2 = F.normalize(z2)
        return torch.mm(z1, z2.t())

    def semi_loss1(self, z1: torch.Tensor, z2: torch.Tensor):
        f = lambda x: torch.exp(x / self.tau)
        refl_sim = f(self.sim(z1, z1))
        between_sim = f(self.sim(z1, z2))

        return -torch.log(between_sim.diag() / (refl_sim.sum(1) + between_sim.sum(1) - refl_sim.diag()))



    def loss1(self, z1: torch.Tensor, z2: torch.Tensor, mean: bool = True, batch_size: Optional[int] = None):
        h1 = self.projection(z1)
        h2 = self.projection(z2)

        if batch_size is None:
            l1 = self.semi_loss1(h1, h2)
            l2 = self.semi_loss1(h2, h1)
        else:
            l1 = self.batched_semi_loss(h1, h2, batch_size)
            l2 = self.batched_semi_loss(h2, h1, batch_size)

        ret = (l1 + l2) * 0.5
        ret = ret.mean() if mean else ret.sum()

        return ret

    def graph_semi_loss(self, c1: torch.Tensor, c1_: torch.Tensor, c2: torch.Tensor, c2_: torch.Tensor, c_kg: torch.Tensor, c_kg_: torch.Tensor):
        f = lambda x: torch.exp(x / self.tau)
        f(self.sim(c1,c1_))
        return -torch.log( (f(self.sim(c1,c2))+ f(self.sim(c1,c_kg)))/ (f(self.sim(c1,c2))+ f(self.sim(c1,c_kg))+ f(self.sim(c1,c1_))+ f(self.sim(c1,c2_))+f(self.sim(c1,c_kg_))))

    def graph_loss(self, c1: torch.Tensor, c1_: torch.Tensor, c2: torch.Tensor, c2_: torch.Tensor, c_kg: torch.Tensor, c_kg_: torch.Tensor, mean: bool = True, batch_size: Optional[int] = None):
        h1 = self.projection(c1)
        h1_ = self.projection(c1_)
        h2 = self.projection(c2)
        h2_ = self.projection(c2_)
        h_kg = self.projection(c_kg)
        h_kg_ = self.projection(c_kg_)
        if batch_size is None:
            l1 = self.graph_semi_loss(h1, h1_, h2, h2_, h_kg, h_kg_)
            l2 = self.graph_semi_loss(h2, h2_, h1, h1_, h_kg, h_kg_)
            l_kg = self.graph_semi_loss(h_kg, h_kg_, h1, h1_, h2, h2_)
        else:
            l1 = self.batched_semi_loss(h1, h2, batch_size)
            l2 = self.batched_semi_loss(h2, h1, batch_size)

        ret = (l1 + l2 + l_kg) / 3
        ret = ret.mean() if mean else ret.sum()

        return ret


    def semi_loss(self, z1: torch.Tensor ,z2: torch.Tensor, adj: torch.Tensor,mean):
        f = lambda x: torch.exp(x / self.tau)
        refl_sim = f(self.sim(z1, z1))
        between_sim = f(self.sim(z1, z2))
        if mean:
            pos = between_sim.diag()+ (refl_sim * adj).sum(1) / (adj.sum(1) + 0.01)
        else:
            pos = between_sim.diag() + (refl_sim * adj).sum(1)
        neg = refl_sim.sum(1) + between_sim.sum(1) - refl_sim.diag() - (refl_sim * adj).sum(1)
        loss = -torch.log(pos / (pos + neg))

        return loss


    def loss(self, z1: torch.Tensor,  z2: torch.Tensor, adj: torch.Tensor, mean: bool = True, batch_size: Optional[int] = None):
        h1 = self.projection(z1)
        h2 = self.projection(z2)


        if batch_size is None:
            l1 = self.semi_loss(h1,  h2, adj, mean)
            l2 = self.semi_loss(h2,  h1, adj, mean)
        else:
            l1 = self.batched_semi_loss(h1, h2, adj, batch_size)
            l2 = self.batched_semi_loss(h2, h1, adj, batch_size)

        ret = (l1 + l2) * 0.5
        ret = ret.mean() if mean else ret.sum()

        return ret

def glorot(tensor):#inits.py中
    if tensor is not None:
        stdv = math.sqrt(6.0 / (tensor.size(-2) + tensor.size(-1)))
        tensor.data.uniform_(-stdv, stdv)#将tensor的值设置为-stdv, stdv之间
def zeros(tensor):
    if tensor is not None:
        tensor.data.fill_(0)





class LogReg(nn.Module):
    def __init__(self, ft_in, nb_classes):
        super(LogReg, self).__init__()
        self.fc = nn.Linear(ft_in, nb_classes)

        for m in self.modules():
            self.weights_init(m)

    def weights_init(self, m):
        if isinstance(m, nn.Linear):
            torch.nn.init.xavier_uniform_(m.weight.data)
            if m.bias is not None:
                m.bias.data.fill_(0.0)

    def forward(self, seq):
        ret = self.fc(seq)
        return ret


class MLP(nn.Module):
    def __init__(self, input_dim, hidden_dim, out_dim):
        super().__init__()

        self.fc_1 = nn.Linear(input_dim, hidden_dim)
        self.fc_2 = nn.Linear(hidden_dim, out_dim)

    def forward(self, x):
        h_1 = F.relu(self.fc_1(x))

        h_2 = self.fc_2(h_1)

        return h_2

class Readout(nn.Module):
    def __init__(self):
        super(Readout, self).__init__()

    def forward(self, seq, msk=None):
        if msk is None:
            return torch.mean(seq, 0, keepdim=True)
        else:
            msk = torch.unsqueeze(msk, -1)
            return torch.mean(seq * msk, 0, keepdim=True) / torch.sum(msk)


class Neighbor(nn.Module):
    def __init__(self, device, num_centroids, num_kmeans, clus_num_iters):
        super(Neighbor, self).__init__()
        self.device = device
        self.num_centroids = num_centroids
        self.num_kmeans = num_kmeans
        self.clus_num_iters = clus_num_iters

    def __get_close_nei_in_back(self, indices, each_k_idx, cluster_labels, back_nei_idxs, k):
        # get which neighbors are close in the background set
        batch_labels = cluster_labels[each_k_idx][indices]
        top_cluster_labels = cluster_labels[each_k_idx][back_nei_idxs]
        batch_labels = repeat_1d_tensor(batch_labels, k)

        curr_close_nei = torch.eq(batch_labels, top_cluster_labels)
        return curr_close_nei

    def forward(self, z, adj, top_k):
        n_data, d = z.shape
        similarity = torch.matmul(z, torch.transpose(z, 1, 0).detach())
        similarity += torch.eye(n_data, device=self.device) * 10

        _, I_knn = similarity.topk(k=top_k, dim=1, largest=True, sorted=True)
        tmp = torch.LongTensor(np.arange(n_data)).unsqueeze(-1).to(self.device)
        knn_neighbor = self.create_sparse(I_knn)
        # knn_neighbor = knn_neighbor.to(torch.float64)
        # adj =adj.to(torch.float64)
        locality = torch.mul(knn_neighbor, adj)

        ncentroids = self.num_centroids
        niter = self.clus_num_iters

        pred_labels = []

        for seed in range(self.num_kmeans):
            kmeans = faiss.Kmeans(d, ncentroids, niter=niter, gpu=False, seed=seed + 1234)
            kmeans.train(z.cpu().detach().numpy())
            _, I_kmeans = kmeans.index.search(z.cpu().detach().numpy(), 1)

            clust_labels = I_kmeans[:, 0]

            pred_labels.append(clust_labels)

        pred_labels = np.stack(pred_labels, axis=0)
        cluster_labels = torch.from_numpy(pred_labels).long()

        all_close_nei_in_back = None
        with torch.no_grad():
            for each_k_idx in range(self.num_kmeans):
                curr_close_nei = self.__get_close_nei_in_back(tmp.squeeze(-1), each_k_idx, cluster_labels, I_knn,
                                                              I_knn.shape[1])

                if all_close_nei_in_back is None:
                    all_close_nei_in_back = curr_close_nei
                else:
                    all_close_nei_in_back = all_close_nei_in_back | curr_close_nei

        all_close_nei_in_back = all_close_nei_in_back.to(self.device)

        globality = self.create_sparse_revised(I_knn, all_close_nei_in_back)

        pos_ = locality + globality
        return pos_
        # return pos_.coalesce()._indices(), I_knn.shape[1]

    def create_sparse(self, I):

        similar = I.reshape(-1).tolist()
        index = np.repeat(range(I.shape[0]), I.shape[1])

        assert len(similar) == len(index)
        indices = torch.tensor([index, similar]).to(self.device)
        result = torch.sparse_coo_tensor(indices, torch.ones_like(I.reshape(-1)), [I.shape[0], I.shape[0]])

        return result

    def create_sparse_revised(self, I, all_close_nei_in_back):
        n_data, k = I.shape[0], I.shape[1]

        index = []
        similar = []
        for j in range(I.shape[0]):
            for i in range(k):
                index.append(int(j))
                similar.append(I[j][i].item())

        index = torch.masked_select(torch.LongTensor(index).to(self.device), all_close_nei_in_back.reshape(-1))
        similar = torch.masked_select(torch.LongTensor(similar).to(self.device), all_close_nei_in_back.reshape(-1))

        assert len(similar) == len(index)
        indices = torch.tensor([index.cpu().numpy().tolist(), similar.cpu().numpy().tolist()]).to(self.device)
        result = torch.sparse_coo_tensor(indices, torch.ones(len(index)).to(self.device), [n_data, n_data])

        return result
