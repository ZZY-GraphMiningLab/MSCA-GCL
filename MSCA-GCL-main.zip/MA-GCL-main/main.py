import argparse
import os.path as osp
import random
import nni
import yaml
from yaml import SafeLoader
import numpy as np
import scipy
import torch
from torch_scatter import scatter_add
import torch.nn as nn
from torch_geometric.utils import dropout_adj, degree, to_undirected, get_laplacian,to_networkx
import torch.nn.functional as F
import networkx as nx
from scipy.sparse.linalg import eigs, eigsh

from torch_geometric.utils import get_laplacian, to_scipy_sparse_matrix
from simple_param.sp import SimpleParam
from pGRACE.model import Encoder, GRACE, MLP, Readout, Neighbor
from pGRACE.functional import drop_feature, drop_edge_weighted, \
    degree_drop_weights, \
    evc_drop_weights, pr_drop_weights, \
    feature_drop_weights, drop_feature_weighted_2, feature_drop_weights_dense, community_detection, transition,community_strength, get_edge_weight, get_smooth_edge_weight,ced
from pGRACE.eval import log_regression, MulticlassEvaluator
from pGRACE.utils import get_base_model, get_activation, \
    generate_split, compute_pr, eigenvector_centrality,knn_graph
from pGRACE.dataset import get_dataset
from utils import normalize_adjacency_matrix, create_adjacency_matrix, load_adj_neg, Rank
from torch_geometric.nn import GCNConv
import warnings
import networkx
warnings.filterwarnings("ignore")


def train():
    model.train()
    #view_learner.eval()
    optimizer.zero_grad()
    # edge_index_1 = dropout_adj(data.edge_index, p=drop_edge_rate_1)[0]
    # edge_index_2 = dropout_adj(data.edge_index, p=drop_edge_rate_2)[0] #adjacency with edge droprate 2

    edge_index_1 = ced(data.edge_index, edge_weight, p=drop_edge_rate_1, threshold=1)
    edge_index_2 = ced(data.edge_index, edge_weight, p=drop_edge_rate_2, threshold=1)

    # data.kg_edge_index = knn_graph(data.x, k=5, metric='cosine')
    # data.kg_edge_index = data.kg_edge_index.cuda()
    edge_index_3 = dropout_adj(data.kg_edge_index, p=drop_edge_rate_3)[0]

    x_1 = drop_feature(data.x, drop_feature_rate_1)#3
    x_2 = drop_feature(data.x, drop_feature_rate_2)#4
    x_3 = drop_feature(data.x, drop_feature_rate_3)

    z1 = model(x_1, edge_index_1)
    z2 = model(x_2, edge_index_2)
    c1 = readout(z1)
    c2 = readout(z2)
    z_kg = model(x_3,edge_index_3)
    c_kg = readout(z_kg)

    idx1 = torch.randperm(data.x.size(0))
    idx2 = torch.randperm(data.x.size(0))
    idx3 = torch.randperm(data.x.size(0))
    shuf_fts_x_1= x_1[idx1, :]
    shuf_fts_x_2 = x_2[idx1, :]
    shuf_fts_x_3 = x_3[idx1, :]

    shuf_fts_z1 = model(shuf_fts_x_1, edge_index_1)
    shuf_fts_z2 = model(shuf_fts_x_2, edge_index_2)
    shuf_fts_c1 = readout(shuf_fts_z1)
    shuf_fts_c2 = readout(shuf_fts_z2)
    shuf_fts_z_kg = model(shuf_fts_x_3, edge_index_3)
    shuf_fts_c_kg = readout(shuf_fts_z_kg)
    z = model(data.x,data.edge_index)
    # adj = create_adjacency_matrix(data.edge_index)
    # indices = torch.LongTensor([adj.row, adj.col])
    # values = torch.FloatTensor(adj.data)
    # adj = torch.sparse_coo_tensor(indices, values, size=adj.shape)
    # adj = adj.to("cuda:1")
    # pos = neighbor(z, adj, top_k).to_dense()
    # adj1 = create_adjacency_matrix(edge_index_1)
    # indices1 = torch.LongTensor([adj1.row, adj1.col])
    # values1 = torch.FloatTensor(adj1.data)
    # adj1 = torch.sparse_coo_tensor(indices1, values1, size=adj.shape)
    # adj1 = adj1.to("cuda:1")
    # pos1 = neighbor(z1, adj1, top_k).to_dense()
    # adj2 = create_adjacency_matrix(edge_index_2)
    # indices2 = torch.LongTensor([adj2.row, adj2.col])
    # values2 = torch.FloatTensor(adj2.data)
    # adj2 = torch.sparse_coo_tensor(indices2, values2, size=adj.shape)
    # adj2 = adj2.to("cuda:1")
    # pos2 = neighbor(z2, adj2, top_k).to_dense()
    # adj3 = create_adjacency_matrix(edge_index_3)
    # indices3 = torch.LongTensor([adj3.row, adj3.col])
    # values3 = torch.FloatTensor(adj3.data)
    # adj3 = torch.sparse_coo_tensor(indices3, values3, size=adj.shape)
    # adj3 = adj3.to("cuda:1")
    # pos3 = neighbor(z_kg, adj3, top_k).to_dense()
    # z1_div = model(x_1,edge_index_1)
    # z2_div = model(x_2, edge_index_2)
    loss0 = model.loss1(z1, z2, batch_size=None)
    # loss2 = model.loss(z1, z2_div, batch_size=None)
    # loss3 = model.loss(z1_div, z2, batch_size=None)
    loss1 = model.loss1(z1, z_kg, batch_size=64 if args.dataset == 'Coauthor-Phy' or args.dataset == 'ogbn-arxiv' else None)
    # loss2 = model.loss(z2, z_kg,batch_size=64 if args.dataset == 'Coauthor-Phy' or args.dataset == 'ogbn-arxiv' else None)
    # loss3 = model.loss(z, z_kg,batch_size=64 if args.dataset == 'Coauthor-Phy' or args.dataset == 'ogbn-arxiv' else None)
    loss2 = model.graph_loss(c1, shuf_fts_c1, c2, shuf_fts_c2, c_kg, shuf_fts_c_kg)
    loss = loss0 + loss1 + 0.1 * loss2
    # loss = loss0 + 0.6 * loss2
    # loss = loss0
    loss.backward()
    optimizer.step()

    return loss.item()


def test(final=False):

    model.eval()
    z = model(data.x, data.edge_index)

    evaluator = MulticlassEvaluator()
    if args.dataset == 'WikiCS':
        accs = []
        accs_1 = []
        accs_2 = []
        for i in range(20):
            acc = log_regression(z, dataset, evaluator, split=f'wikics:{i}', num_epochs=800)['acc']
            accs.append(acc)
        acc = sum(accs) / len(accs)
    else:
        if args.dataset == 'Cora' or args.dataset == 'CiteSeer' or  args.dataset == 'PubMed':
            acc = log_regression(z, dataset, evaluator, split='preloaded', num_epochs=3000, preload_split=split)['acc']
            # acc = log_regression(z, dataset, evaluator, split='rand:0.1', num_epochs=3000, preload_split=0)['acc']
        else : acc = log_regression(z, dataset, evaluator, split='rand:0.1', num_epochs=3000, preload_split=0)['acc']
        #acc_2 = log_regression(z2, dataset, evaluator2, split='rand:0.1', num_epochs=3000, preload_split=split)['acc']

    if final and use_nni:
        nni.report_final_result(acc)
    elif use_nni:
        nni.report_intermediate_result(acc)

    return acc#, acc_1, acc_2


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--device', type=str, default='cuda:0')
    parser.add_argument('--dataset', type=str, default='CiteSeer')
    parser.add_argument('--config', type=str, default='param.yaml')
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--verbose', type=str, default='train,eval,final')
    parser.add_argument('--save_split', type=str, nargs='?')
    parser.add_argument('--load_split', type=str, nargs='?')
    parser.add_argument('--cd', type=str, default='leiden')
    parser.add_argument("--clus_num_iters", type=int, default=20)
    parser.add_argument("--num_centroids", type=int, default=100, help="The number of centroids for K-means Clustering")
    parser.add_argument("--num_kmeans", type=int, default=5,
                        help="The number of K-means Clustering for being robust to randomness")
    parser.add_argument("--top_k", type=int, default=4, help="The number of neighbors to search")
    args = parser.parse_args()

    config = yaml.load(open(args.config), Loader=SafeLoader)[args.dataset]

    torch.manual_seed(args.seed)
    random.seed(0)
    np.random.seed(args.seed)
    use_nni = args.config == 'nni'
    learning_rate = config['learning_rate']
    num_hidden = config['num_hidden']
    num_proj_hidden = config['num_proj_hidden']
    activation = config['activation']
    base_model = config['base_model']
    num_layers = config['num_layers']
    dataset = args.dataset
    drop_edge_rate_1 = config['drop_edge_rate_1']
    drop_edge_rate_2 = config['drop_edge_rate_2']
    drop_edge_rate_3 = config['drop_edge_rate_3']
    drop_feature_rate_1 = config['drop_feature_rate_1']
    drop_feature_rate_2 = config['drop_feature_rate_2']
    drop_feature_rate_3 = config['drop_feature_rate_3']
    k = config['k']
    drop_scheme = config['drop_scheme']
    tau = config['tau']
    num_epochs = config['num_epochs']
    weight_decay = config['weight_decay']
    rand_layers = config['rand_layers']
    clus_num_iters = config['clus_num_iters']
    num_centroids = config['num_centroids']
    num_kmeans = config['num_kmeans']
    top_k = config['top_k']
    device = torch.device(args.device)

    path = osp.expanduser('~/datasets')
    path = osp.join(path, args.dataset)
    dataset = get_dataset(path, args.dataset)
    
    data = dataset[0]
    data = data.to(device)

    adj = 0
    data.kg_edge_index = knn_graph(data.x, k, metric='cosine')
    data.kg_edge_index = data.kg_edge_index.to(device)
    
    if args.dataset == 'Cora' or args.dataset == 'CiteSeer' or  args.dataset == 'PubMed': split = (data.train_mask, data.val_mask, data.test_mask)

    print('Detecting communities...')
    g = to_networkx(data, to_undirected=True)
    communities = community_detection(args.cd)(g).communities
    com = transition(communities, g.number_of_nodes())
    com_cs, node_cs = community_strength(g, communities)
    edge_weight = get_edge_weight(data.edge_index, com, com_cs)
    # edge_weight = get_smooth_edge_weight(data.edge_index, com)
    com_size = [len(c) for c in communities]
    print(f'Done! {len(com_size)} communities detected. \n')
    print(com_cs)
    # print('Knn Graph Detecting communities...')
    # data.kg_edge_index = knn_graph(data.x, k=5, metric='cosine')
    # data.kg_edge_index = data.kg_edge_index.cuda()
    # g = to_networkx(data, to_undirected=True)
    # communities = community_detection(args.cd)(g).communities
    # com = transition(communities, g.number_of_nodes())
    # com_cs, node_cs = community_strength(g, communities)
    # edge_weight = get_edge_weight(data.edge_index, com, com_cs)
    # # edge_weight = get_smooth_edge_weight(data.edge_index, com)
    # com_size = [len(c) for c in communities]
    # print(f'Done! {len(com_size)} communities detected. \n')

    encoder = Encoder(dataset.num_features, num_hidden, get_activation(activation),
                      base_model=GCNConv, k=num_layers).to(device)

    model = GRACE(encoder, num_hidden, num_proj_hidden, tau).to(device)

    readout = Readout()
    # mlp = MLP(num_hidden,  num_proj_hidden,num_hidden).to(device)
    neighbor = Neighbor(device, num_centroids, num_kmeans, clus_num_iters)
    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=learning_rate,
        weight_decay=weight_decay
    )

    log = args.verbose.split(',')

    for epoch in range(1, num_epochs + 1):

        loss = train()
        if 'train' in log:
            print(f'(T) | Epoch={epoch:03d}, loss={loss:.4f}')
        if epoch % 100 == 0:
            acc = test()
            x_1 = drop_feature(data.x, drop_feature_rate_1)#3
            x_2 = drop_feature(data.x, drop_feature_rate_2)#4
            #x_3 = drop_feature(sub_x, drop_feature_rate_1)

            edge_index_2 = dropout_adj(data.edge_index, p=drop_edge_rate_2)[0] #adjacency with edge droprate 2
            edge_index_1 = dropout_adj(data.edge_index, p=drop_edge_rate_1)[0] #adjacency with edge droprate 2
            z = model(data.x, data.edge_index).detach().cpu().numpy()
            # z1 = model(x_1, edge_index_1).detach().cpu().numpy()
            # z2 = model(x_2, edge_index_2).detach().cpu().numpy()
            # np.save('embedding/'+args.dataset + 'view1_embeddingfull.npy', z1)
            # np.save('embedding/'+args.dataset + 'view2_embeddingfull.npy', z2)
            np.save('embedding/'+args.dataset + 'Graph_embeddingfull.npy', z)
            if 'eval' in log:
                print(f'(E) | Epoch={epoch:04d}, avg_acc = {acc}')


    acc = test(final=True)

    if 'final' in log:
        print(f'{acc}')

